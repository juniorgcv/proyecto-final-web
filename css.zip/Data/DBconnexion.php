<?php

$servidor="localhost";
$BaseDeDatos="datablibreria";
$usuario="root";
$contrasenia="123456";

try{ 
    $conexion= new PDO("mysql:host=$servidor;bdname=$BaseDeDatos",$usuario,$contrasenia);
    $conexion->exec("USE $BaseDeDatos");
}catch(Exception $ex){
    echo $ex->getMessage();
}

?>

